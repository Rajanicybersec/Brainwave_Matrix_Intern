import re
from urllib.parse import urlparse

# Simple blacklist for demonstration
blacklisted_domains = ["phishing.com", "malicious-site.net", "login-facebook-security.com"]

def is_phishing_url(url):
    parsed_url = urlparse(url)
    domain = parsed_url.netloc
    path = parsed_url.path

    reasons = []

    # Blacklist check
    if domain in blacklisted_domains:
        reasons.append("Blacklisted domain")

    # Check for '@' in URL
    if '@' in url:
        reasons.append("Contains '@' character")

    # Check if URL uses IP address instead of domain
    if re.match(r'https?://\d+\.\d+\.\d+\.\d+', url):
        reasons.append("Uses IP address instead of domain name")

    # Check if HTTPS is used
    if not url.startswith("https://"):
        reasons.append("Does not use HTTPS")

    # Check for suspicious characters
    if '-' in domain:
        reasons.append("Domain contains '-'")

    # Check for excessive subdomains
    if domain.count('.') > 2:
        reasons.append("Too many subdomains")

    if len(reasons) == 0:
        return False, "URL looks safe"
    else:
        return True, "Phishing indicators: " + ", ".join(reasons)

# ---- CLI entry point ----
if __name__ == "__main__":
    url = input("Enter a URL to scan: ")
    is_phishing, message = is_phishing_url(url)
    print("\n[RESULT]")
    if is_phishing:
        print(f"⚠️ Phishing link detected! Reason(s): {message}")
    else:
        print(f"✅ Safe URL: {message}")
